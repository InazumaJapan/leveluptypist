import pygame
import random
import sys
import os
import math
import asyncio # <-- 1. Added asyncio

pygame.init()

WIDTH, HEIGHT = 1280, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
main_surf = pygame.Surface((WIDTH, HEIGHT))
pygame.display.set_caption("Typing Escape")

clock = pygame.time.Clock()

print("========================================")
print("ตำแหน่งโฟลเดอร์ที่ Python กำลังทำงานอยู่คือ:")
print(os.getcwd())
print("========================================")

# ---------- ระบบ High Score ----------
highscore = 0
if os.path.exists("highscore.txt"):
    with open("highscore.txt", "r") as f:
        try:
            highscore = int(f.read())
        except:
            pass

def save_highscore(score):
    global highscore
    if score > highscore:
        highscore = score
        with open("highscore.txt", "w") as f:
            f.write(str(highscore))

# ---------- โหลดภาพและพื้นหลัง ----------
backgrounds = []
for i in range(1, 21):
    bg_name = f"bg{i}.png"
    try:
        bg = pygame.image.load(bg_name).convert()
        bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))
        backgrounds.append(bg)
    except:
        break

if not backgrounds:
    try:
        bg = pygame.image.load("bg.png").convert()
        backgrounds.append(pygame.transform.scale(bg, (WIDTH, HEIGHT)))
    except:
        pass

def load_img(name, w, h):
    try:
        img = pygame.image.load(name).convert_alpha()
        return pygame.transform.scale(img, (w, h)), True
    except:
        return None, False

menu_background, use_menu_bg = load_img("menu_bg.png", WIDTH, HEIGHT)
gameover_img, use_gameover_img = load_img("gameover.png", WIDTH, HEIGHT)
gameover_boss_img, use_gameover_boss_img = load_img("gameover_boss.png", WIDTH, HEIGHT)
victory_img, use_victory_img = load_img("victory.png", WIDTH, HEIGHT)

player_w, player_h = 80, 110
monster_w, monster_h = 80, 110
boss_w, boss_h = 160, 240

player_img, use_player_img = load_img("player.png", player_w, player_h)
monster_img, use_monster_img = load_img("monster.png", monster_w, monster_h)
boss_img, use_boss_img = load_img("boss.png", boss_w, boss_h)

# ---------- สีและฟอนต์ ----------
WHITE = (255, 255, 255)
BLACK = (30, 30, 30)
BLUE = (70, 120, 255)
GREEN = (50, 200, 100)
RED = (220, 80, 80)
PURPLE = (160, 70, 200)
YELLOW = (240, 200, 50)
GOLD = (255, 215, 0)
CYAN = (0, 255, 255)
ORANGE = (255, 140, 0)
TOXIC_PURPLE = (210, 50, 255)

font_title = pygame.font.SysFont("consolas", 80, bold=True)
font_big = pygame.font.SysFont("consolas", 64, bold=True)
font_mid = pygame.font.SysFont("consolas", 40)
font_small = pygame.font.SysFont("consolas", 30)

# ---------- คำศัพท์ ----------
WORDS_EASY = ["cat", "dog", "bat", "ant", "bird", "fish", "frog", "bear", "sun", "moon", "star", "sky", "wind", "fire",
              "ice", "snow", "run", "walk", "jump", "fly", "swim", "play", "game", "time", "red", "blue", "code", "bug",
              "web", "app", "data", "file"]
WORDS_MID = ["apple", "banana", "orange", "grape", "cherry", "melon", "animal", "forest", "desert", "ocean", "river",
             "island", "castle", "knight", "dragon", "wizard", "magic", "sword", "planet", "rocket", "typing", "python",
             "monster", "escape", "window", "screen", "button", "system", "network", "health", "energy", "speed",
             "power", "smart", "quick", "super"]
WORDS_HARD = ["keyboard", "computer", "programming", "developer", "software", "hardware", "internet", "database",
              "algorithm", "function", "variable", "condition", "interface", "technology", "security", "challenge",
              "adventure", "experience", "knowledge", "beautiful", "dangerous", "mysterious", "invincible",
              "spectacular", "environment"]

def get_word_for_level(level, current_word=""):
    pool = WORDS_EASY if level <= 2 else WORDS_MID if level <= 4 else WORDS_HARD
    new_word = random.choice(pool)
    while new_word == current_word: new_word = random.choice(pool)
    return new_word

ITEMS = ["Slow Monster", "Push Monster Back", "Dash Forward"]

ground_y = 550
player_y = ground_y - player_h
monster_y = ground_y - monster_h
finish_line_x = WIDTH - 80

# ---------- สร้างเกมใหม่ ----------
def new_game():
    return {
        "level": 1,
        "current_word": get_word_for_level(1, ""),
        "is_cursed": False,
        "typed_text": "",
        "char_index": 0,
        "score": 0,
        "player_x": 150,

        "monster_x": 20,
        "monster_speed": 0.28,

        "is_boss_level": False,
        "boss_x": 0, "boss_speed": 0, "boss_hp": 0, "boss_max_hp": 0,
        "fireballs": [], "floaters": [],

        "message": "", "message_timer": 0, "reward_item": "",
        "active_target": None, "special_word": "", "special_typed": "",
        "special_cooldown": random.uniform(15.0, 25.0),
        "special_lifetime": 0.0, "freeze_timer": 0.0,

        "combo": 0, "stun_timer": 0.0, "shake_timer": 0.0
    }

# ---------- 2. Wrapped the main loop in async def main() ----------
async def main():
    game = new_game()
    state = "MENU"
    running = True

    # ---------- Loop ----------
    while running:
        dt = clock.tick(60) / 1000

        # --- พื้นหลัง ---
        if state == "MENU":
            if use_menu_bg:
                main_surf.blit(menu_background, (0, 0))
            else:
                main_surf.fill(BLACK)
        elif state == "INSTRUCTIONS":
            main_surf.fill(WHITE)
        elif state == "GAME_OVER":
            if game["is_boss_level"] and use_gameover_boss_img:
                main_surf.blit(gameover_boss_img, (0, 0))
            elif use_gameover_img:
                main_surf.blit(gameover_img, (0, 0))
            else:
                main_surf.fill(BLACK)
        elif state == "BOSS_VICTORY":
            if use_victory_img:
                main_surf.blit(victory_img, (0, 0))
            else:
                main_surf.fill(GOLD)
        else:
            if backgrounds:
                main_surf.blit(backgrounds[(game["level"] - 1) % len(backgrounds)], (0, 0))
            else:
                main_surf.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if state == "MENU":
                    if event.key == pygame.K_RETURN:
                        state = "INSTRUCTIONS"

                elif state == "INSTRUCTIONS":
                    if event.key == pygame.K_RETURN:
                        game = new_game()
                        state = "PLAY"

                elif state == "PLAY":
                    if game["stun_timer"] > 0 and event.key != pygame.K_ESCAPE: continue
                    if event.key == pygame.K_ESCAPE:
                        state = "PAUSE"

                    elif event.key == pygame.K_BACKSPACE:
                        game["combo"] = 0
                        if game["active_target"] == "NORMAL" and game["typed_text"]:
                            game["typed_text"] = game["typed_text"][:-1]
                            game["char_index"] -= 1
                            if not game["is_boss_level"]: game["player_x"] -= 15
                            if not game["typed_text"]: game["active_target"] = None
                        elif game["active_target"] == "SPECIAL" and game["special_typed"]:
                            game["special_typed"] = game["special_typed"][:-1]
                            if not game["special_typed"]: game["active_target"] = None

                    elif event.unicode.isalpha():
                        char = event.unicode.lower()
                        correct_keypress, moved = False, False

                        if game["active_target"] is None:
                            normal_expected = game["current_word"][-1] if game["is_cursed"] else game["current_word"][0]
                            if char == normal_expected:
                                game["active_target"] = "NORMAL"
                                game["typed_text"] += char
                                game["char_index"] += 1
                                correct_keypress = moved = True
                            elif game["special_word"] and char == game["special_word"][0]:
                                game["active_target"] = "SPECIAL"
                                game["special_typed"] += char
                                correct_keypress = True

                        elif game["active_target"] == "NORMAL":
                            if game["char_index"] < len(game["current_word"]):
                                normal_expected = game["current_word"][
                                    len(game["current_word"]) - 1 - game["char_index"]] if game["is_cursed"] else \
                                game["current_word"][game["char_index"]]
                                if char == normal_expected:
                                    game["typed_text"] += char
                                    game["char_index"] += 1
                                    correct_keypress = moved = True

                        elif game["active_target"] == "SPECIAL":
                            s_idx = len(game["special_typed"])
                            if s_idx < len(game["special_word"]) and char == game["special_word"][s_idx]:
                                game["special_typed"] += char
                                correct_keypress = True

                        if correct_keypress:
                            game["combo"] += 1
                            step_size = 30 if game["combo"] >= 15 else 15

                            game["floaters"].append({
                                "char": char.upper(),
                                "x": game["player_x"] + player_w // 2 + random.randint(-20, 20),
                                "y": player_y, "life": 0.6
                            })

                            if game["is_boss_level"] and moved:
                                game["fireballs"].append({"x": game["player_x"] + player_w,
                                                          "y": player_y + player_h // 2 + random.randint(-15, 15)})
                            elif moved and not game["is_boss_level"]:
                                game["player_x"] += step_size

                            if moved and game["char_index"] == len(game["current_word"]):
                                game["score"] += 1
                                game["char_index"] = 0
                                game["typed_text"] = ""
                                game["message"] = "CURSE LIFTED!" if game["is_cursed"] else "Correct!"
                                game["message_timer"] = 0.6
                                game["current_word"] = get_word_for_level(game["level"], game["current_word"])
                                game["is_cursed"] = (game["level"] >= 3 and random.random() < 0.25)
                                game["active_target"] = None

                                if not game["is_boss_level"] and game["player_x"] + player_w >= finish_line_x:
                                    game["level"] += 1
                                    game["reward_item"] = random.choice(ITEMS)
                                    game["char_index"] = 0;
                                    game["typed_text"] = ""
                                    game["current_word"] = get_word_for_level(game["level"], game["current_word"])
                                    game["is_cursed"] = False;
                                    game["active_target"] = None
                                    state = "REWARD"

                            elif game["active_target"] == "SPECIAL":
                                if len(game["special_typed"]) == len(game["special_word"]):
                                    if game["special_word"] == "freeze":
                                        game["freeze_timer"] = 3.0;
                                        game["message"] = "FROZEN!"
                                    elif game["special_word"] == "bomb":
                                        if game["is_boss_level"]:
                                            game["boss_x"] = min(game["boss_x"] + 150, WIDTH - boss_w)
                                        else:
                                            game["monster_x"] = max(game["monster_x"] - 150, 0)
                                        game["message"] = "BOMBED!"
                                    game["message_timer"] = 1.0
                                    game["special_word"] = game["special_typed"] = ""
                                    game["active_target"] = None
                                    game["special_cooldown"] = random.uniform(15.0, 25.0)
                        else:
                            game["combo"] = 0
                            game["stun_timer"] = 0.5
                            game["shake_timer"] = 0.3
                            game["message"] = "STUNNED!"
                            game["message_timer"] = 0.5

                elif state == "PAUSE":
                    if event.key in [pygame.K_ESCAPE, pygame.K_RETURN]: state = "PLAY"
                elif state == "BOSS_VICTORY":
                    if event.key == pygame.K_RETURN: state = "REWARD"

                elif state == "REWARD":
                    if event.key == pygame.K_RETURN:
                        if game["level"] % 5 == 0:
                            game["is_boss_level"] = True
                            game["boss_hp"] = game["boss_max_hp"] = 40 + (game["level"] * 4)
                            game["boss_x"] = WIDTH - 250
                            game["boss_speed"] = 0.20 + (game["level"] * 0.01)
                            game["player_x"] = 150;
                            game["fireballs"] = []
                        else:
                            game["is_boss_level"] = False
                            game["player_x"] = 150;
                            game["monster_x"] = 20
                            game["monster_speed"] = 0.28 + ((game["level"] - 1) * 0.03)

                            if game["reward_item"] in ["Slow Monster", "BOSS DEFEATED!"]:
                                game["monster_speed"] *= 0.7
                            elif game["reward_item"] == "Push Monster Back":
                                game["monster_x"] -= 100
                            elif game["reward_item"] == "Dash Forward":
                                game["player_x"] += 100
                        game["combo"] = 0
                        state = "PLAY"

                elif state == "GAME_OVER":
                    if event.key == pygame.K_RETURN: state = "MENU"

        # ---------- Logic ----------
        if state == "PLAY":
            if game["stun_timer"] > 0: game["stun_timer"] -= dt
            if game["freeze_timer"] > 0:
                game["freeze_timer"] -= dt
            else:
                if game["is_boss_level"]:
                    game["boss_x"] -= game["boss_speed"]
                else:
                    game["monster_x"] += game["monster_speed"]

            if game["is_boss_level"] and game["boss_x"] <= game["player_x"] + player_w:
                save_highscore(game["score"]);
                state = "GAME_OVER"
            elif not game["is_boss_level"] and game["monster_x"] + monster_w >= game["player_x"]:
                save_highscore(game["score"]);
                state = "GAME_OVER"

            for f in game["floaters"][:]:
                f["y"] -= 60 * dt;
                f["life"] -= dt
                if f["life"] <= 0: game["floaters"].remove(f)

            if game["is_boss_level"]:
                for fb in game["fireballs"][:]:
                    fb["x"] += 25
                    if fb["x"] >= game["boss_x"]:
                        game["boss_hp"] -= 1;
                        game["fireballs"].remove(fb)
                        if game["boss_hp"] <= 0:
                            game["boss_hp"] = 0;
                            game["level"] += 1
                            game["reward_item"] = "BOSS DEFEATED!"
                            game["char_index"] = 0;
                            game["typed_text"] = ""
                            game["current_word"] = get_word_for_level(game["level"])
                            game["is_cursed"] = False;
                            game["active_target"] = None
                            game["fireballs"] = [];
                            game["is_boss_level"] = False
                            state = "BOSS_VICTORY"
                            break

            if game["message_timer"] > 0:
                game["message_timer"] -= dt
                if game["message_timer"] <= 0: game["message"] = ""

            if not game["special_word"]:
                game["special_cooldown"] -= dt
                if game["special_cooldown"] <= 0:
                    game["special_word"] = random.choice(["freeze", "bomb"])
                    game["special_lifetime"] = 5.0
            else:
                game["special_lifetime"] -= dt
                if game["special_lifetime"] <= 0:
                    game["special_word"] = game["special_typed"] = ""
                    if game["active_target"] == "SPECIAL": game["active_target"] = None
                    game["special_cooldown"] = random.uniform(15.0, 25.0)

        # ---------- UI บน main_surf ----------
        if state == "MENU":
            pass

        elif state == "INSTRUCTIONS":
            title = font_big.render("HOW TO PLAY", True, BLACK)
            main_surf.blit(title, title.get_rect(center=(WIDTH // 2, 150)))

            ins1 = font_mid.render("- Type the words on screen to run away.", True, BLACK)
            main_surf.blit(ins1, ins1.get_rect(center=(WIDTH // 2, 250)))

            ins2 = font_mid.render("- GOLD words (FREEZE / BOMB) give you special powers.", True, ORANGE)
            main_surf.blit(ins2, ins2.get_rect(center=(WIDTH // 2, 320)))

            ins3 = font_mid.render("- PURPLE words are CURSED! Type them BACKWARDS.", True, PURPLE)
            main_surf.blit(ins3, ins3.get_rect(center=(WIDTH // 2, 390)))

            ins4 = font_mid.render("- Defeat the BOSS every 5 levels by typing fireballs!", True, RED)
            main_surf.blit(ins4, ins4.get_rect(center=(WIDTH // 2, 460)))

            if pygame.time.get_ticks() % 1000 < 500:
                start_text = font_mid.render("Press ENTER to Start Game", True, BLUE)
                main_surf.blit(start_text, start_text.get_rect(center=(WIDTH // 2, 600)))

        elif state in ["PLAY", "PAUSE"]:
            word_color = TOXIC_PURPLE if game["is_cursed"] else WHITE
            if game["is_cursed"]:
                bob = math.sin(pygame.time.get_ticks() / 150.0) * 5
                main_surf.blit(font_small.render("REVERSE CURSE!", True, TOXIC_PURPLE),
                               font_small.render("REVERSE CURSE!", True, TOXIC_PURPLE).get_rect(
                                   center=(WIDTH // 2, 20 + bob)))

            main_surf.blit(font_big.render(game["current_word"], True, word_color),
                           font_big.render(game["current_word"], True, word_color).get_rect(center=(WIDTH // 2, 60)))
            main_surf.blit(font_mid.render(game["typed_text"], True, BLUE),
                           font_mid.render(game["typed_text"], True, BLUE).get_rect(center=(WIDTH // 2, 120)))

            if game["combo"] > 0:
                combo_color = ORANGE if game["combo"] >= 15 else YELLOW
                main_surf.blit(font_mid.render(f"COMBO: {game['combo']}", True, combo_color), (WIDTH // 2 + 200, 60))

            if game["is_boss_level"]:
                bar_w, bar_h, bar_y, bar_x = 600, 25, 150, WIDTH // 2 - 300
                pygame.draw.rect(main_surf, BLACK, (bar_x, bar_y, bar_w, bar_h))
                pygame.draw.rect(main_surf, RED, (bar_x, bar_y, bar_w * (
                    max(0, game["boss_hp"] / game["boss_max_hp"]) if game["boss_max_hp"] > 0 else 0), bar_h))
                pygame.draw.rect(main_surf, WHITE, (bar_x, bar_y, bar_w, bar_h), 3)
                main_surf.blit(font_small.render(f"BOSS HP: {game['boss_hp']}/{game['boss_max_hp']}", True, WHITE),
                               font_small.render(f"BOSS HP: {game['boss_hp']}/{game['boss_max_hp']}", True, WHITE).get_rect(
                                   center=(WIDTH // 2, bar_y - 20)))

            if game["special_word"]:
                bob_y = math.sin(pygame.time.get_ticks() / 150.0) * 8
                sw_base = font_mid.render(game["special_word"].upper(), True, GOLD).get_rect(
                    center=(WIDTH // 2, 240 + bob_y))
                main_surf.blit(font_mid.render(game["special_word"].upper(), True, GOLD), sw_base)
                if game["special_typed"]: main_surf.blit(font_mid.render(game["special_typed"].upper(), True, CYAN),
                                                         sw_base.topleft)
                pygame.draw.rect(main_surf, BLACK, (sw_base.centerx - 60, sw_base.bottom + 5, 120, 6))
                pygame.draw.rect(main_surf, GOLD,
                                 (sw_base.centerx - 60, sw_base.bottom + 5, 120 * max(0, game["special_lifetime"] / 5.0),
                                  6))

            if game["message"]:
                msg_color = RED if game["message"] == "STUNNED!" else TOXIC_PURPLE if game[
                                                                                          "message"] == "CURSE LIFTED!" else GREEN
                main_surf.blit(font_mid.render(game["message"], True, msg_color),
                               font_mid.render(game["message"], True, msg_color).get_rect(center=(WIDTH // 2, 330)))

            # ---------------- วาดแถบพื้นหลังรองรับ Level / Score / High Score ----------------
            ui_y = 200 if game["is_boss_level"] else 30

            ui_elements = [
                (f"Score: {game['score']}", WHITE, 40, ui_y),
                (f"Level: {game['level']}", WHITE, WIDTH - 180, ui_y),
                (f"High: {highscore}", GOLD, WIDTH - 180, HEIGHT - 60)
            ]

            for txt, clr, x, y in ui_elements:
                t_surf = font_small.render(txt, True, clr)
                t_rect = t_surf.get_rect(topleft=(x, y))
                bg_rect = t_rect.inflate(20, 10)

                bg_panel = pygame.Surface(bg_rect.size, pygame.SRCALPHA)
                pygame.draw.rect(bg_panel, (0, 0, 0, 150), bg_panel.get_rect(), border_radius=8)

                main_surf.blit(bg_panel, bg_rect.topleft)
                main_surf.blit(t_surf, t_rect)

        elif state == "REWARD":
            box = pygame.Rect(0, 0, 500, 250);
            box.center = (WIDTH // 2, HEIGHT // 2)
            pygame.draw.rect(main_surf, WHITE, box, border_radius=15);
            pygame.draw.rect(main_surf, YELLOW, box, 5, border_radius=15)
            main_surf.blit(
                font_big.render("ITEM GET!" if game["reward_item"] != "BOSS DEFEATED!" else "VICTORY!", True, BLACK),
                font_big.render("ITEM GET!", True, BLACK).get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))
            main_surf.blit(font_mid.render(game["reward_item"], True, PURPLE),
                           font_mid.render(game["reward_item"], True, PURPLE).get_rect(
                               center=(WIDTH // 2, HEIGHT // 2 + 20)))
            if pygame.time.get_ticks() % 1000 < 500:
                main_surf.blit(font_small.render("Press ENTER", True, BLACK),
                               font_small.render("Press ENTER", True, BLACK).get_rect(
                                   center=(WIDTH // 2, HEIGHT // 2 + 80)))

        elif state == "BOSS_VICTORY":
            if not use_victory_img:
                main_surf.blit(font_title.render("BOSS DEFEATED!", True, BLACK),
                               font_title.render("BOSS DEFEATED!", True, BLACK).get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            main_surf.blit(font_mid.render("Press ENTER to Continue", True, BLACK),
                           font_mid.render("Press ENTER to Continue", True, BLACK).get_rect(
                               center=(WIDTH // 2 + 3, HEIGHT - 77)))
            main_surf.blit(font_mid.render("Press ENTER to Continue", True, WHITE),
                           font_mid.render("Press ENTER to Continue", True, WHITE).get_rect(
                               center=(WIDTH // 2, HEIGHT - 80)))

        elif state == "GAME_OVER":
            has_custom_bg = (game["is_boss_level"] and use_gameover_boss_img) or (
                        not game["is_boss_level"] and use_gameover_img) or use_gameover_img
            if has_custom_bg:
                main_surf.blit(font_mid.render("Press ENTER to Menu", True, BLACK),
                               font_mid.render("Press ENTER to Menu", True, BLACK).get_rect(
                                   center=(WIDTH // 2 + 3, HEIGHT - 77)))
                main_surf.blit(font_mid.render("Press ENTER to Menu", True, WHITE),
                               font_mid.render("Press ENTER to Menu", True, WHITE).get_rect(
                                   center=(WIDTH // 2, HEIGHT - 80)))
            else:
                go_bg = pygame.Surface((500, 200), pygame.SRCALPHA);
                go_bg.fill((255, 255, 255, 220))
                main_surf.blit(go_bg, go_bg.get_rect(center=(WIDTH // 2, HEIGHT // 2)).topleft)
                main_surf.blit(font_big.render("GAME OVER", True, RED),
                               font_big.render("GAME OVER", True, RED).get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30)))
                main_surf.blit(font_mid.render("Press ENTER to Menu", True, BLACK),
                               font_mid.render("Press ENTER to Menu", True, BLACK).get_rect(
                                   center=(WIDTH // 2, HEIGHT // 2 + 40)))

            main_surf.blit(font_mid.render(f"Final Score: {game['score']}", True, YELLOW),
                           font_mid.render(f"Final Score: {game['score']}", True, YELLOW).get_rect(
                               center=(WIDTH // 2, HEIGHT // 2 - 120)))

        # ---------- วาดฉากต่อสู้ ----------
        if state in ["PLAY", "REWARD", "PAUSE"]:
            pygame.draw.line(main_surf, WHITE, (0, ground_y), (WIDTH, ground_y), 4)

            if not game["is_boss_level"]:
                pygame.draw.line(main_surf, GREEN, (finish_line_x, ground_y), (finish_line_x, ground_y - 120), 5)
                main_surf.blit(font_small.render("FINISH", True, GREEN), (finish_line_x - 45, ground_y - 150))

            if game["combo"] >= 15:
                fire_surface = pygame.Surface((player_w + 30, player_h + 30), pygame.SRCALPHA)
                alpha_glow = abs(math.sin(pygame.time.get_ticks() / 100.0)) * 100 + 100
                pygame.draw.ellipse(fire_surface, (255, 140, 0, alpha_glow), fire_surface.get_rect())
                pygame.draw.ellipse(fire_surface, (255, 200, 0, alpha_glow), fire_surface.get_rect().inflate(-20, -20))
                main_surf.blit(fire_surface, (game["player_x"] - 15, player_y - 15))

            if use_player_img:
                main_surf.blit(player_img, (game["player_x"], player_y))
            else:
                pygame.draw.rect(main_surf, BLUE, (game["player_x"], player_y, player_w, player_h), border_radius=10)

            if game["is_boss_level"]:
                for fb in game["fireballs"]:
                    pygame.draw.circle(main_surf, ORANGE, (int(fb["x"]), int(fb["y"])), 12)
                    pygame.draw.circle(main_surf, YELLOW, (int(fb["x"]), int(fb["y"])), 6)
                if use_boss_img:
                    main_surf.blit(boss_img, (game["boss_x"], ground_y - boss_h))
                else:
                    pygame.draw.rect(main_surf, RED, (game["boss_x"], ground_y - boss_h, boss_w, boss_h), border_radius=20)
                if state in ["PLAY", "PAUSE"] and game["freeze_timer"] > 0:
                    ice_block = pygame.Surface((boss_w + 20, boss_h + 20), pygame.SRCALPHA);
                    ice_block.fill((0, 255, 255, 130))
                    main_surf.blit(ice_block, (game["boss_x"] - 10, ground_y - boss_h - 10))
            else:
                if use_monster_img:
                    main_surf.blit(monster_img, (game["monster_x"], monster_y))
                else:
                    pygame.draw.rect(main_surf, PURPLE, (game["monster_x"], monster_y, monster_w, monster_h),
                                     border_radius=10)
                if state in ["PLAY", "PAUSE"] and game["freeze_timer"] > 0:
                    ice_block = pygame.Surface((monster_w + 10, monster_h + 10), pygame.SRCALPHA);
                    ice_block.fill((0, 255, 255, 130))
                    main_surf.blit(ice_block, (game["monster_x"] - 5, monster_y - 5))

            if game["stun_timer"] > 0:
                main_surf.blit(font_small.render("X", True, RED), (game["player_x"] + player_w // 2 - 10, player_y - 40))

            for f in game["floaters"]:
                txt = font_small.render(f["char"], True, YELLOW)
                txt.set_alpha(max(0, int((f["life"] / 0.6) * 255)))
                main_surf.blit(txt, (f["x"], f["y"]))

        if state == "PAUSE":
            pause_overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA);
            pause_overlay.fill((0, 0, 0, 180))
            main_surf.blit(pause_overlay, (0, 0))
            main_surf.blit(font_big.render("PAUSED", True, WHITE),
                           font_big.render("PAUSED", True, WHITE).get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30)))
            main_surf.blit(font_mid.render("Press ESC to Resume", True, YELLOW),
                           font_mid.render("Press ESC to Resume", True, YELLOW).get_rect(
                               center=(WIDTH // 2, HEIGHT // 2 + 40)))

        shake_x, shake_y = 0, 0
        if state == "PLAY" and game["shake_timer"] > 0:
            game["shake_timer"] -= dt
            shake_x, shake_y = random.randint(-10, 10), random.randint(-10, 10)

        screen.blit(main_surf, (shake_x, shake_y))
        pygame.display.flip()

        # ---------- 3. The crucial WebAssembly pause ----------
        await asyncio.sleep(0)

# ---------- 4. Start the async function ----------
asyncio.run(main())

# (We remove sys.exit() and pygame.quit() as they can sometimes abruptly terminate the browser's web worker)